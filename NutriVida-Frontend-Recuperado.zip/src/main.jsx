import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext.jsx";
import { ServiciosProvider } from "./context/ServiciosContext.jsx";
import { CitasProvider } from "./context/CitasContext.jsx";
import App from "./App.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
    <React.StrictMode>
        <BrowserRouter>
            <AuthProvider>
                <ServiciosProvider>
                    <CitasProvider>
                        <App />
                    </CitasProvider>
                </ServiciosProvider>
            </AuthProvider>
        </BrowserRouter>
    </React.StrictMode>
);